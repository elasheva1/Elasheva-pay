import { useEffect, useState } from 'react';

const api = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const money = (n) => new Intl.NumberFormat('en-NG', {
  style: 'currency', currency: 'NGN', maximumFractionDigits: 2
}).format(n);

export default function App() {
  const [health, setHealth] = useState('Checking API…');
  const [balance, setBalance] = useState(45250);
  const [tab, setTab] = useState('Home');

  useEffect(() => {
    fetch(`${api}/api/health`)
      .then((r) => r.ok ? r.json() : Promise.reject())
      .then((d) => setHealth(`API ${d.status} · ${d.mode} mode`))
      .catch(() => setHealth('API offline · start backend to connect'));
  }, []);

  const actions = [
    ['＋', 'Fund wallet'], ['↗', 'Transfer'],
    ['↓', 'Withdraw'], ['▦', 'Pay bills']
  ];

  return <main className="app-shell">
    <header className="topbar">
      <div className="brand-mark">E</div>
      <div><strong>ELASHEVA PAY</strong><small>Payments made simpler</small></div>
      <div className="avatar">EP</div>
    </header>

    <section className="welcome">
      <p className="eyebrow">YOUR MONEY SPACE</p>
      <h1>Hello, welcome back</h1>
      <p>Manage your payments in one place.</p>
    </section>

    <section className="balance-card">
      <div className="balance-heading"><span>Demo wallet balance</span><span className="demo-pill">DEMO</span></div>
      <h2>{money(balance)}</h2>
      <p>Illustrative sample balance · Not real funds</p>
      <button className="light-button" onClick={() => setBalance(45250)}>Refresh display</button>
    </section>

    <section className="section">
      <div className="section-title"><h2>Quick actions</h2><span>Explore</span></div>
      <div className="actions">{actions.map(([symbol, label]) =>
        <button className="action" key={label} onClick={() => alert(`${label} is a demo screen. No money will move.`)}>
          <span className="action-icon">{symbol}</span><span>{label}</span>
        </button>)}</div>
    </section>

    <section className="section">
      <div className="section-title"><h2>Recent activity</h2><span>View all</span></div>
      <div className="transaction"><span className="tx-icon">↙</span><div><strong>Wallet funding</strong><small>Sample transaction · Today</small></div><b className="positive">+ ₦10,000</b></div>
      <div className="transaction"><span className="tx-icon bill">▤</span><div><strong>Electricity bill</strong><small>Sample transaction · Yesterday</small></div><b>- ₦5,000</b></div>
      <div className="transaction"><span className="tx-icon transfer">↗</span><div><strong>Bank transfer</strong><small>Sample transaction · Yesterday</small></div><b>- ₦2,500</b></div>
    </section>

    <p className="api-status">{health}</p>
    <nav className="bottom-nav">{['Home','Transactions','Wallet','Support','Profile'].map(item =>
      <button key={item} className={tab === item ? 'selected' : ''} onClick={() => setTab(item)}>{item}</button>)}</nav>
    <footer>Elasheva Pay · Prototype interface</footer>
  </main>;
}
