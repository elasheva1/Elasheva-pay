# Elasheva Pay — GitHub Starter

A starter repository for the Elasheva Pay interface and API. This is a **development/demo scaffold**, not a live wallet or payment service. It does not move money, verify bank transfers, or store real customer funds.

## Contents
- `frontend/`: React + Vite mobile-friendly dashboard interface
- `backend/`: Express API health endpoint and demo transaction endpoint
- `.env.example`: placeholders only — never put real keys in GitHub
- `Dockerfile`: basic backend container
- `.gitignore`: excludes secrets and dependencies

## Requirements
- Node.js 20+
- npm

## Run locally

### Backend
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```
API defaults to `http://localhost:4000`.

### Frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Vite prints the local development URL. The frontend uses `VITE_API_URL` and defaults to `http://localhost:4000`.

## GitHub upload
1. Extract this ZIP.
2. Create a new repository on GitHub named `elasheva-pay`.
3. Upload the extracted files/folders (not the ZIP itself), or use Git:
   ```bash
   git init
   git add .
   git commit -m "Initial Elasheva Pay starter"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/elasheva-pay.git
   git push -u origin main
   ```

## Before production
This starter is not production-ready for real money. Before a pilot, implement and independently test authentication, authorization, secure ledger accounting, database migrations, idempotent payment webhooks, reconciliation, audit logs, monitoring, rate limiting, secrets management, backups, and incident response. Integrate a licensed payment partner (for example, through their approved sandbox first) and obtain appropriate Nigerian regulatory/legal review or authorization. Never represent a demo balance as spendable funds.
