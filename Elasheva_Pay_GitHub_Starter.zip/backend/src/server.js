import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';

const app = express();
const port = Number(process.env.PORT || 4000);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '20kb' }));

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'elasheva-pay-api', mode: 'demo' });
});

// Demo-only endpoint: this is not a financial ledger and must not be used
// to authorize transfers or represent real balances.
app.get('/api/demo/summary', (_req, res) => {
  res.json({
    mode: 'demo',
    currency: 'NGN',
    displayBalance: 45250,
    note: 'Illustrative sample data only; not real funds.'
  });
});

app.post('/api/demo/transactions', (req, res) => {
  const { type, amount } = req.body ?? {};
  if (typeof type !== 'string' || !type.trim()) {
    return res.status(400).json({ error: 'type is required' });
  }
  if (typeof amount !== 'number' || !Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ error: 'amount must be a positive number' });
  }
  return res.status(201).json({
    mode: 'demo',
    accepted: false,
    message: 'Demo only: no transaction was created and no money moved.',
    submitted: { type: type.trim(), amount }
  });
});

app.use((_req, res) => res.status(404).json({ error: 'Not found' }));
app.listen(port, () => console.log(`Elasheva Pay demo API listening on port ${port}`));
