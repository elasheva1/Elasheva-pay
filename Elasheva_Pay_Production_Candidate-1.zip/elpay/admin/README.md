# Elasheva Pay Admin Dashboard

Recommended production web dashboard:
- React/Next.js + TypeScript
- Protected admin routes with MFA
- User search and account status
- Payment monitoring
- Failed/pending payment queue
- Webhook event inspection
- Reconciliation reports
- Audit log viewer
- Role-based permissions (support, finance, compliance, super-admin)
- Export controls with least-privilege access

The API already exposes `/v1/admin/overview` and `/v1/admin/audit-logs` as the starting point.
