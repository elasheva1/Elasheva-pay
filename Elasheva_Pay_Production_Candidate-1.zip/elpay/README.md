# Elasheva Pay — Production Candidate

This repository is a production-oriented implementation of the Elasheva Pay payment application. It is **not** a declaration of CBN authorization, PCI certification, penetration-test certification, or legal compliance.

## Components
- `backend/` — Fastify + TypeScript API, Prisma/PostgreSQL, OTP/PIN authentication, Paystack payment initialization/verification, signed/idempotent webhooks, wallet ledger, admin endpoints and Prometheus metrics.
- `mobile/` — Flutter mobile UI with onboarding/sign-in, OTP flow, dashboard, wallet balance, payment initialization and navigation shell.
- `admin/` — minimal operations dashboard consuming protected admin APIs.
- `SECURITY_VALIDATION.md` — implemented controls, automated-check status and required independent validation.
- `DEPLOYMENT.md` — deployment and production security checklist.

## Backend commands
```bash
cd backend
npm install
npm run security
npm test
npm run build
```

Or run all automated checks:
```bash
npm run check
```

## Local database
Configure `DATABASE_URL`, then run the Prisma migration through your controlled deployment process.

## Important production gates
1. Use a managed PostgreSQL database with encrypted storage and point-in-time recovery.
2. Store production secrets in a managed secret store.
3. Configure a real SMS/email provider for OTP delivery; the API never returns OTP codes.
4. Use provider-hosted/tokenized checkout and never collect raw card PAN/CVV in Elasheva infrastructure.
5. Complete provider sandbox tests and daily settlement reconciliation.
6. Complete SAST, dependency scanning, container scanning, DAST and independent penetration testing.
7. Complete Nigerian legal/compliance review and establish the appropriate licensed payment-partner or CBN authorization model before real-money launch.
