# Deployment and security checklist

## Production
- PostgreSQL managed instance with encrypted storage, backups and point-in-time recovery.
- API behind HTTPS load balancer/WAF.
- Secrets in a managed secret store; never commit `.env`.
- Separate staging and production databases and payment keys.
- Run Prisma migrations as a controlled deployment step.
- Restrict database network access to the API.
- Central logs + metrics + alerting; monitor `/metrics`, latency, error rate and payment reconciliation.
- Error tracking should capture server errors without storing OTPs, PINs, card data or access tokens.
- Use dependency scanning, SAST, secret scanning and container image scanning in CI.
- Perform DAST against staging and an independent penetration test before launch.
- Rate-limit auth, OTP, PIN, payment initialization and webhook endpoints.
- Add account/device risk controls and admin MFA.

## Payment security
- Never collect or store raw card PAN/CVV in Elasheva infrastructure; use provider-hosted/tokenized checkout.
- Treat redirects as UX only; server verification/webhooks determine payment state.
- Make webhook processing idempotent using provider event ID plus payment reference.
- Reconcile provider settlements against internal ledger daily.

## OTP/PIN
- OTPs are short-lived, single-use, hashed at rest, rate-limited and never returned by API.
- PINs are slow-hashed; failed attempts trigger temporary lockout.
- Production SMS/email delivery must use a vetted provider; the development logger must be removed.

## Compliance gate
Do not publicly launch stored-value wallet/transfer functionality until Nigerian counsel/compliance specialists confirm the correct CBN licensing/partner model, AML/KYC obligations, consumer protection, data protection and reporting requirements for the exact business model.
