import Fastify, {FastifyRequest} from "fastify";
import fastifyJwt from "@fastify/jwt";
import fastifyRateLimit from "@fastify/rate-limit";
import fastifyRawBody from "@fastify/raw-body";
import bcrypt from "bcryptjs";
import {PrismaClient,PaymentProvider,PaymentStatus,LedgerDirection,OtpPurpose,Prisma} from "@prisma/client";
import {z} from "zod";
import {generateOtp,hashOtp,generateReference,safeEqualHex,sha256,hmacSha512,normalizePhone} from "./security.js";
import {registry,httpRequests} from "./monitoring.js";

const prisma=new PrismaClient();
const app=Fastify({logger:{redact:["req.headers.authorization","req.body.pin","req.body.code","req.body.password"]},bodyLimit:1024*1024});
const env={
 port:Number(process.env.PORT??3000),
 jwt:process.env.JWT_SECRET??"", otpSecret:process.env.OTP_HASH_SECRET??"",
 otpTtl:Number(process.env.OTP_TTL_SECONDS??300),
 paystack:process.env.PAYSTACK_SECRET_KEY??"", webhook:process.env.PAYSTACK_WEBHOOK_SECRET||process.env.PAYSTACK_SECRET_KEY||"",
 nodeEnv:process.env.NODE_ENV??"development"
};
if(!env.jwt||env.jwt.length<32||!env.otpSecret||env.otpSecret.length<32) throw new Error("JWT_SECRET and OTP_HASH_SECRET must each be at least 32 characters");
if(env.nodeEnv==="production" && (!env.paystack||env.paystack.includes("test")||!env.webhook)) throw new Error("Production Paystack credentials/webhook secret are required");

await app.register(fastifyJwt,{secret:env.jwt});
await app.register(fastifyRateLimit,{global:false});
await app.register(fastifyRawBody,{field:"rawBody",global:false,encoding:"utf8",runFirst:true});
declare module "@fastify/jwt"{interface FastifyJWT{user:{id:string,email:string,role:string}}}
declare module "fastify"{interface FastifyRequest{rawBody?:string}}

app.addHook("onResponse",async(req,res)=>{httpRequests.inc({method:req.method,route:req.routeOptions.url??req.url,status:String(res.statusCode)})});
app.get("/health",async()=>({ok:true,service:"elasheva-pay-api"}));
app.get("/ready",async(_,reply)=>{try{await prisma.$queryRaw`SELECT 1`;return {ok:true}}catch{return reply.code(503).send({ok:false})}});
app.get("/metrics",async(_,reply)=>reply.type(registry.contentType).send(await registry.metrics()));

async function auth(req:FastifyRequest,rep:any){try{await req.jwtVerify()}catch{return rep.code(401).send({error:"Unauthorized"})}}
async function admin(req:FastifyRequest,rep:any){await auth(req,rep);if(req.user?.role!=="ADMIN")return rep.code(403).send({error:"Forbidden"})}
async function audit(actorUserId:string|undefined,action:string,targetType?:string,targetId?:string,metadata?:Record<string,unknown>){await prisma.auditLog.create({data:{actorUserId,action,targetType,targetId,metadata:metadata as Prisma.InputJsonValue|undefined}}).catch(()=>undefined)}

const authRate={max:5,timeWindow:"1 minute"};
app.post("/v1/auth/request-otp",{config:{rateLimit:authRate}},async(req,rep)=>{
 const x=z.object({destination:z.string().min(7).max(120),purpose:z.nativeEnum(OtpPurpose)}).parse(req.body);
 const destination=x.destination.includes("@")?x.destination.trim().toLowerCase():normalizePhone(x.destination);
 const recent=await prisma.otpChallenge.count({where:{destination,purpose:x.purpose,createdAt:{gt:new Date(Date.now()-60_000)}}});
 if(recent>=3)return rep.code(429).send({error:"Too many OTP requests"});
 const code=generateOtp();
 const user=destination.includes("@")?await prisma.user.findUnique({where:{email:destination}}):await prisma.user.findUnique({where:{phone:destination}});
 await prisma.otpChallenge.create({data:{userId:user?.id,destination,purpose:x.purpose,codeHash:hashOtp(code,env.otpSecret),expiresAt:new Date(Date.now()+env.otpTtl*1000)}});
 // Never return OTP. A real SMS/email provider must deliver it outside this API.
 req.log.info({purpose:x.purpose,destinationSuffix:destination.slice(-3)},"OTP challenge created");
 return {ok:true,expiresIn:env.otpTtl};
});

app.post("/v1/auth/verify-otp",{config:{rateLimit:authRate}},async(req,rep)=>{
 const x=z.object({destination:z.string().min(7).max(120),purpose:z.nativeEnum(OtpPurpose),code:z.string().regex(/^\d{6}$/),name:z.string().trim().min(2).max(100).optional()}).parse(req.body);
 const destination=x.destination.includes("@")?x.destination.trim().toLowerCase():normalizePhone(x.destination);
 const ch=await prisma.otpChallenge.findFirst({where:{destination,purpose:x.purpose,consumedAt:null,expiresAt:{gt:new Date()}},orderBy:{createdAt:"desc"}});
 if(!ch)return rep.code(400).send({error:"Invalid or expired OTP"});
 if(ch.attempts>=5)return rep.code(429).send({error:"OTP locked; request a new code"});
 const ok=safeEqualHex(ch.codeHash,hashOtp(x.code,env.otpSecret));
 if(!ok){await prisma.otpChallenge.update({where:{id:ch.id},data:{attempts:{increment:1}}});return rep.code(400).send({error:"Invalid or expired OTP"});}
 await prisma.otpChallenge.update({where:{id:ch.id},data:{consumedAt:new Date()}});
 let user=ch.userId?await prisma.user.findUnique({where:{id:ch.userId}}):destination.includes("@")?await prisma.user.findUnique({where:{email:destination}}):await prisma.user.findUnique({where:{phone:destination}});
 if(x.purpose===OtpPurpose.SIGNUP && !user){
   user=await prisma.user.create({data:{name:x.name??"Elasheva Pay User",email:destination.includes("@")?destination:`${destination.replace(/\D/g,"")}@phone.elasheva.local`,phone:destination.includes("@")?undefined:destination,passwordHash:null,wallet:{create:{currency:"NGN"}}}});
 }
 if(!user)return rep.code(404).send({error:"Account not found"});
 const token=await app.jwt.sign({id:user.id,email:user.email,role:user.role},{expiresIn:"30m"});
 await audit(user.id,"AUTH_OTP_VERIFIED","User",user.id,{purpose:x.purpose});
 return {verified:true,accessToken:token,user:{id:user.id,name:user.name,email:user.email,phone:user.phone,role:user.role}};
});

app.post("/v1/auth/set-pin",{preHandler:auth,config:{rateLimit:{max:10,timeWindow:"5 minutes"}}},async(req:any,rep)=>{
 const x=z.object({pin:z.string().regex(/^\d{6}$/)}).parse(req.body);
 const hash=await bcrypt.hash(x.pin,12);
 await prisma.user.update({where:{id:req.user.id},data:{pinHash:hash,pinAttempts:0,lockedUntil:null}});
 await audit(req.user.id,"PIN_SET","User",req.user.id);
 return {ok:true};
});
app.post("/v1/auth/verify-pin",{preHandler:auth,config:{rateLimit:{max:20,timeWindow:"5 minutes"}}},async(req:any,rep)=>{
 const x=z.object({pin:z.string().regex(/^\d{6}$/)}).parse(req.body);
 const u=await prisma.user.findUnique({where:{id:req.user.id}});
 if(!u?.pinHash)return rep.code(400).send({error:"PIN not set"});
 if(u.lockedUntil&&u.lockedUntil>new Date())return rep.code(423).send({error:"PIN temporarily locked"});
 const ok=await bcrypt.compare(x.pin,u.pinHash);
 if(!ok){const attempts=u.pinAttempts+1;await prisma.user.update({where:{id:u.id},data:{pinAttempts:attempts,lockedUntil:attempts>=5?new Date(Date.now()+15*60*1000):null}});return rep.code(401).send({error:"Invalid PIN"})}
 await prisma.user.update({where:{id:u.id},data:{pinAttempts:0}}); return {verified:true};
});

const paymentInput=z.object({amountNaira:z.number().positive().max(10_000_000),email:z.string().email().optional()});
app.post("/v1/payments/initialize",{preHandler:auth,config:{rateLimit:{max:20,timeWindow:"1 minute"}}},async(req:any,rep)=>{
 const x=paymentInput.parse(req.body); if(!env.paystack)return rep.code(503).send({error:"Payment provider not configured"});
 const amountKobo=BigInt(Math.round(x.amountNaira*100)); const reference=generateReference();
 const user=await prisma.user.findUnique({where:{id:req.user.id}}); if(!user)return rep.code(404).send({error:"User not found"});
 const response=await fetch("https://api.paystack.co/transaction/initialize",{method:"POST",headers:{Authorization:`Bearer ${env.paystack}`,"Content-Type":"application/json"},body:JSON.stringify({email:x.email??user.email,amount:Number(amountKobo),reference,metadata:{userId:user.id}})});
 if(!response.ok)return rep.code(502).send({error:"Payment provider unavailable"});
 const body=await response.json() as any; if(!body.status||!body.data?.authorization_url)return rep.code(502).send({error:"Payment initialization failed"});
 await prisma.paymentIntent.create({data:{userId:user.id,provider:PaymentProvider.PAYSTACK,reference,amountKobo,currency:"NGN",status:PaymentStatus.PENDING,checkoutUrl:body.data.authorization_url}});
 await audit(user.id,"PAYMENT_INITIALIZED","PaymentIntent",reference,{amountKobo:amountKobo.toString()});
 return {reference,checkoutUrl:body.data.authorization_url,accessCode:body.data.access_code};
});

app.post("/v1/payments/:reference/verify",{preHandler:auth,config:{rateLimit:{max:20,timeWindow:"1 minute"}}},async(req:any,rep)=>{
 const reference=z.string().min(3).parse(req.params.reference);
 const p=await prisma.paymentIntent.findUnique({where:{reference}});
 if(!p||p.userId!==req.user.id)return rep.code(404).send({error:"Payment not found"});
 if(p.status===PaymentStatus.SUCCESS)return {reference,status:p.status};
 if(p.provider!==PaymentProvider.PAYSTACK||!env.paystack)return rep.code(503).send({error:"Payment provider not configured"});
 const response=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${env.paystack}`}});
 if(!response.ok)return rep.code(502).send({error:"Payment provider unavailable"});
 const body=await response.json() as any;
 if(body?.status && body?.data?.status==="success"){
   const providerAmount=Number(body.data.amount);
   if(providerAmount!==Number(p.amountKobo))return rep.code(409).send({error:"Payment amount mismatch"});
   await fulfillPaystack(reference,String(body.data.id??reference));
 }
 const updated=await prisma.paymentIntent.findUnique({where:{reference}});
 return {reference,status:updated?.status??PaymentStatus.FAILED};
});

app.get("/v1/payments/:reference",{preHandler:auth},async(req:any,rep)=>{
 const ref=z.string().min(3).parse(req.params.reference); const p=await prisma.paymentIntent.findUnique({where:{reference:ref}});
 if(!p||p.userId!==req.user.id)return rep.code(404).send({error:"Payment not found"});
 return {...p,amountNaira:Number(p.amountKobo)/100};
});

async function fulfillPaystack(reference:string,providerTxId:string){
 return prisma.$transaction(async(tx)=>{
   const p=await tx.paymentIntent.findUnique({where:{reference}}); if(!p)return false;
   if(p.status===PaymentStatus.SUCCESS)return true;
   if(p.status!==PaymentStatus.PENDING)return false;
   const customer=await tx.ledgerAccount.upsert({where:{code:`USER:${p.userId}:WALLET`},create:{code:`USER:${p.userId}:WALLET`,name:`Wallet ${p.userId}`,currency:p.currency},update:{}});
   const clearing=await tx.ledgerAccount.upsert({where:{code:"PAYSTACK:CLEARING"},create:{code:"PAYSTACK:CLEARING",name:"Paystack Clearing",currency:p.currency},update:{}});
   await tx.ledgerEntry.createMany({data:[
     {userId:p.userId,accountId:customer.id,paymentIntentId:p.id,direction:LedgerDirection.CREDIT,amountKobo:p.amountKobo,currency:p.currency,reference:`${p.reference}:wallet`},
     {userId:p.userId,accountId:clearing.id,paymentIntentId:p.id,direction:LedgerDirection.DEBIT,amountKobo:p.amountKobo,currency:p.currency,reference:`${p.reference}:clearing`}
   ]});
   await tx.paymentIntent.update({where:{id:p.id},data:{status:PaymentStatus.SUCCESS,providerTxId,fulfilledAt:new Date()}});
   return true;
 });
}

app.post("/v1/webhooks/paystack",{config:{rawBody:true,rateLimit:{max:120,timeWindow:"1 minute"}}},async(req:any,rep)=>{
 const sig=String(req.headers["x-paystack-signature"]??""); const raw=req.rawBody??JSON.stringify(req.body); const expected=hmacSha512(raw,env.webhook);
 if(!safeEqualHex(sig,expected))return rep.code(401).send({error:"Invalid signature"});
 const event=req.body as any,eventId=String(event?.id??event?.data?.id??sha256(raw));
 try{await prisma.webhookEvent.create({data:{provider:"PAYSTACK",eventId,payloadHash:sha256(raw),payload:event}})}catch{return {received:true,duplicate:true}};
 try{
   if(event?.event==="charge.success"&&event?.data?.status==="success"&&event?.data?.reference){
     await fulfillPaystack(String(event.data.reference),String(event.data.id??event.data.reference));
   }
   await prisma.webhookEvent.updateMany({where:{provider:"PAYSTACK",eventId},data:{processedAt:new Date(),status:"PROCESSED"}});
 }catch(e){await prisma.webhookEvent.updateMany({where:{provider:"PAYSTACK",eventId},data:{status:"FAILED"}});req.log.error(e,"Webhook processing failed");return rep.code(500).send({error:"Webhook processing failed"});}
 return {received:true};
});

app.get("/v1/wallet",{preHandler:auth},async(req:any,rep)=>{
 const wallet=await prisma.wallet.findUnique({where:{userId:req.user.id}}); if(!wallet)return rep.code(404).send({error:"Wallet not found"});
 const account=await prisma.ledgerAccount.findUnique({where:{code:`USER:${req.user.id}:WALLET`}});
 const entries=account?await prisma.ledgerEntry.findMany({where:{accountId:account.id},select:{direction:true,amountKobo:true}}):[];
 const balance=entries.reduce((s,e)=>s+(e.direction===LedgerDirection.CREDIT?e.amountKobo:-e.amountKobo),0n);
 return {currency:wallet.currency,balanceKobo:balance.toString(),balanceNaira:Number(balance)/100};
});
app.get("/v1/transactions",{preHandler:auth},async(req:any)=>{
 const q=z.object({limit:z.coerce.number().int().min(1).max(100).default(50)}).parse(req.query);
 return prisma.paymentIntent.findMany({where:{userId:req.user.id},orderBy:{createdAt:"desc"},take:q.limit,select:{reference:true,amountKobo:true,currency:true,status:true,provider:true,createdAt:true,fulfilledAt:true}});
});

app.get("/v1/admin/overview",{preHandler:admin},async()=>{const [users,pending,success,failed]=await Promise.all([prisma.user.count(),prisma.paymentIntent.count({where:{status:"PENDING"}}),prisma.paymentIntent.count({where:{status:"SUCCESS"}}),prisma.paymentIntent.count({where:{status:"FAILED"}})]);return {users,pendingPayments:pending,successfulPayments:success,failedPayments:failed}});
app.get("/v1/admin/audit-logs",{preHandler:admin},async()=>prisma.auditLog.findMany({orderBy:{createdAt:"desc"},take:200}));

const shutdown=async()=>{await app.close();await prisma.$disconnect();process.exit(0)};process.on("SIGTERM",shutdown);process.on("SIGINT",shutdown);
await app.listen({port:env.port,host:"0.0.0.0"});
