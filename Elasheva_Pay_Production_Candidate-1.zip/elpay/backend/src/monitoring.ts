import client from "prom-client";
export const registry=new client.Registry();
client.collectDefaultMetrics({register:registry});
export const httpRequests=new client.Counter({name:"elasheva_http_requests_total",help:"HTTP requests",labelNames:["method","route","status"]});
registry.registerMetric(httpRequests);
