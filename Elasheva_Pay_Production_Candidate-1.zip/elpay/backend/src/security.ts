import crypto from "node:crypto";

export function hashOtp(code:string, secret:string){
  return crypto.createHmac("sha256",secret).update(code).digest("hex");
}
export function safeEqualHex(a:string,b:string){
  if(!/^[0-9a-f]+$/i.test(a)||!/^[0-9a-f]+$/i.test(b)) return false;
  const aa=Buffer.from(a,"hex"), bb=Buffer.from(b,"hex");
  return aa.length===bb.length && aa.length>0 && crypto.timingSafeEqual(aa,bb);
}
export function generateOtp(){return String(crypto.randomInt(100000,1000000));}
export function generateReference(prefix="EP"){return `${prefix}-${crypto.randomUUID()}`;}
export function sha256(value:string|Buffer){return crypto.createHash("sha256").update(value).digest("hex");}
export function hmacSha512(value:string|Buffer,secret:string){return crypto.createHmac("sha512",secret).update(value).digest("hex");}
export function normalizePhone(phone:string){return phone.replace(/[\s()-]/g,"");}
export function maskSecret(value:string){return value.length<8?"***":`${value.slice(0,3)}***${value.slice(-3)}`;}
