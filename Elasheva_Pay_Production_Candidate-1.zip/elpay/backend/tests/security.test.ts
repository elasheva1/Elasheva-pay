import {describe,it,expect} from "vitest";
import {generateOtp,hashOtp,safeEqualHex,hmacSha512,sha256,generateReference,normalizePhone} from "../src/security.js";
describe("security primitives",()=>{
 it("generates a six digit OTP",()=>expect(generateOtp()).toMatch(/^\d{6}$/));
 it("hashes OTP deterministically",()=>expect(hashOtp("123456","secret")).toBe(hashOtp("123456","secret")));
 it("does not hash different OTPs equally",()=>expect(hashOtp("123456","secret")).not.toBe(hashOtp("654321","secret")));
 it("uses constant-time hex comparison safely",()=>{const h=hashOtp("123456","secret");expect(safeEqualHex(h,h)).toBe(true);expect(safeEqualHex(h,hashOtp("654321","secret"))).toBe(false);expect(safeEqualHex("bad","zz")).toBe(false)});
 it("creates unique payment references",()=>expect(generateReference()).toMatch(/^EP-[0-9a-f-]{36}$/));
 it("normalizes phone formatting",()=>expect(normalizePhone("+234 801-234-5678")).toBe("+2348012345678"));
 it("computes stable hashes and webhook signatures",()=>{expect(sha256("abc")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");expect(hmacSha512("abc","secret")).toHaveLength(128)});
});
