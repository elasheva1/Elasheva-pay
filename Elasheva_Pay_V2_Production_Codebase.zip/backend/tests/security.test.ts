import {describe,it,expect} from "vitest";
import {generateOtp,hashOtp} from "../src/security";
describe("security primitives",()=>{
 it("generates a six digit OTP",()=>expect(generateOtp()).toMatch(/^\d{6}$/));
 it("hashes OTP deterministically",()=>expect(hashOtp("123456","secret")).toBe(hashOtp("123456","secret")));
 it("does not hash different OTPs equally",()=>expect(hashOtp("123456","secret")).not.toBe(hashOtp("654321","secret")));
});
