import Fastify from "fastify";
import fastifyJwt from "@fastify/jwt";
import bcrypt from "bcryptjs";
import {PrismaClient,PaymentProvider,PaymentStatus,LedgerDirection,OtpPurpose} from "@prisma/client";
import {z} from "zod";
import crypto from "node:crypto";
import {generateOtp,hashOtp,generateReference} from "./security";
import {registry,httpRequests} from "./monitoring";

const prisma=new PrismaClient();
const app=Fastify({logger:true,bodyLimit:1024*1024});
const env={
 port:Number(process.env.PORT??3000), jwt:process.env.JWT_SECRET??"",
 otpSecret:process.env.OTP_HASH_SECRET??"",
 otpTtl:Number(process.env.OTP_TTL_SECONDS??300),
 paystack:process.env.PAYSTACK_SECRET_KEY??"",
 webhook:process.env.PAYSTACK_WEBHOOK_SECRET??""
};
if(!env.jwt||!env.otpSecret) throw new Error("Missing security secrets");
await app.register(fastifyJwt,{secret:env.jwt});
declare module "@fastify/jwt"{interface FastifyJWT{user:{id:string,email:string,role:string}}}

app.addHook("onResponse",async(req,res)=>{httpRequests.inc({method:req.method,route:req.routeOptions.url,status:String(res.statusCode)})});
app.get("/health",async()=>({ok:true,service:"elasheva-pay-api"}));
app.get("/metrics",async(_,reply)=>reply.type(registry.contentType).send(await registry.metrics()));

async function auth(req:any,rep:any){try{await req.jwtVerify()}catch{return rep.code(401).send({error:"Unauthorized"})}}
async function admin(req:any,rep:any){await auth(req,rep);if(req.user?.role!=="ADMIN")return rep.code(403).send({error:"Forbidden"})}

app.post("/v1/auth/request-otp",async(req)=>{
 const x=z.object({destination:z.string().min(7),purpose:z.enum(["LOGIN","SIGNUP","RESET_PIN"])}).parse(req.body);
 const code=generateOtp();
 await prisma.otpChallenge.create({data:{destination:x.destination,purpose:x.purpose,codeHash:hashOtp(code,env.otpSecret),expiresAt:new Date(Date.now()+env.otpTtl*1000)}});
 // Replace this log with an approved SMS/email provider in production.
 req.log.info({destination:x.destination,otp:code},"OTP generated for development");
 return {ok:true,expiresIn:env.otpTtl};
});
app.post("/v1/auth/verify-otp",async(req,rep)=>{
 const x=z.object({destination:z.string(),purpose:z.enum(["LOGIN","SIGNUP","RESET_PIN"]),code:z.string().length(6)}).parse(req.body);
 const ch=await prisma.otpChallenge.findFirst({where:{destination:x.destination,purpose:x.purpose,consumedAt:null},orderBy:{createdAt:"desc"}});
 if(!ch||ch.expiresAt<new Date()||!crypto.timingSafeEqual(Buffer.from(ch.codeHash),Buffer.from(hashOtp(x.code,env.otpSecret))))return rep.code(400).send({error:"Invalid or expired OTP"});
 await prisma.otpChallenge.update({where:{id:ch.id},data:{consumedAt:new Date()}});
 return {verified:true};
});
app.post("/v1/auth/set-pin",{preHandler:auth},async(req:any,rep)=>{
 const x=z.object({pin:z.string().regex(/^\d{4,6}$/)}).parse(req.body);
 const hash=await bcrypt.hash(x.pin,12);
 await prisma.user.update({where:{id:req.user.id},data:{pinHash:hash,pinAttempts:0,lockedUntil:null}});
 return {ok:true};
});
app.post("/v1/auth/verify-pin",{preHandler:auth},async(req:any,rep)=>{
 const x=z.object({pin:z.string().regex(/^\d{4,6}$/)}).parse(req.body);
 const u=await prisma.user.findUnique({where:{id:req.user.id}});
 if(!u?.pinHash)return rep.code(400).send({error:"PIN not set"});
 if(u.lockedUntil&&u.lockedUntil>new Date())return rep.code(423).send({error:"PIN temporarily locked"});
 const ok=await bcrypt.compare(x.pin,u.pinHash);
 if(!ok){const attempts=u.pinAttempts+1;await prisma.user.update({where:{id:u.id},data:{pinAttempts:attempts,lockedUntil:attempts>=5?new Date(Date.now()+15*60*1000):null}});return rep.code(401).send({error:"Invalid PIN"})}
 await prisma.user.update({where:{id:u.id},data:{pinAttempts:0}});
 return {verified:true};
});

// Idempotent webhook: unique(provider,eventId) is the database guard; fulfillment is also idempotent by payment reference.
app.post("/v1/webhooks/paystack",async(req:any,rep)=>{
 const sig=String(req.headers["x-paystack-signature"]??"");
 const raw=JSON.stringify(req.body);
 const expected=crypto.createHmac("sha512",env.webhook).update(raw).digest("hex");
 if(!sig||sig.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return rep.code(401).send({error:"Invalid signature"});
 const event=req.body as any, eventId=String(event?.id??event?.data?.id??crypto.createHash("sha256").update(raw).digest("hex"));
 try{
  await prisma.webhookEvent.create({data:{provider:"PAYSTACK",eventId,payloadHash:crypto.createHash("sha256").update(raw).digest("hex"),payload:event}});
 }catch{return {received:true,duplicate:true}}
 // Production fulfillment worker should process this event asynchronously and mark processedAt/status.
 return {received:true};
});

app.get("/v1/admin/overview",{preHandler:admin},async()=>{
 const [users,pending,success]=await Promise.all([
  prisma.user.count(),prisma.paymentIntent.count({where:{status:"PENDING"}}),prisma.paymentIntent.count({where:{status:"SUCCESS"}})
 ]);
 return {users,pendingPayments:pending,successfulPayments:success};
});
app.get("/v1/admin/audit-logs",{preHandler:admin},async()=>prisma.auditLog.findMany({orderBy:{createdAt:"desc"},take:200}));

app.listen({port:env.port,host:"0.0.0.0"}).catch(e=>{app.log.error(e);process.exit(1)});
