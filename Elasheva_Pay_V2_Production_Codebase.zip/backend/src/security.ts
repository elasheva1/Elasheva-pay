import crypto from "node:crypto";
export function hashOtp(code:string, secret:string){return crypto.createHmac("sha256",secret).update(code).digest("hex")}
export function safeEqualHex(a:string,b:string){
 const aa=Buffer.from(a,"hex"), bb=Buffer.from(b,"hex");
 return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);
}
export function generateOtp(){return String(crypto.randomInt(100000,1000000))}
export function generateReference(){return `EP-${crypto.randomUUID()}`}
