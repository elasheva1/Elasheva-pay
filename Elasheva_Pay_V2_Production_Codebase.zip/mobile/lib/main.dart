import 'package:flutter/material.dart';
void main()=>runApp(const ElashevaPay());
class ElashevaPay extends StatelessWidget{
 const ElashevaPay({super.key});
 @override Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,title:'Elasheva Pay',
  theme:ThemeData(colorSchemeSeed:const Color(0xff08783e),useMaterial3:true),
  home:const LoginPage());
}
class LoginPage extends StatefulWidget{const LoginPage({super.key});State<LoginPage> createState()=>_LoginPageState();}
class _LoginPageState extends State<LoginPage>{
 final phone=TextEditingController();
 @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
 const Spacer(),const Text('Elasheva Pay',style:TextStyle(fontSize:32,fontWeight:FontWeight.bold)),const SizedBox(height:8),
 const Text('Simple, secure payments.'),const SizedBox(height:30),
 TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Phone number',prefixIcon:Icon(Icons.phone),border:OutlineInputBorder())),
 const SizedBox(height:14),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>showDialog(context:c,builder:(_)=>const OtpDialog()),child:const Text('Continue'))),
 const Spacer(),])));}
}
class OtpDialog extends StatelessWidget{const OtpDialog({super.key});@override Widget build(BuildContext c)=>AlertDialog(title:const Text('Enter OTP'),content:TextField(keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'6-digit OTP')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Verify'))]);}
