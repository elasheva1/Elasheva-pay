# Elasheva Pay Admin / Backend Dashboard

The included dashboard is a lightweight operations console for the Elasheva Pay API. It covers:

- Users
- Wallets and calculated ledger balances
- Transactions and payment status
- Payment-status aggregation
- Ledger/payment reconciliation
- Audit logs
- System health/readiness indicators

## Security requirements

Do not expose the dashboard publicly without TLS, admin authentication/MFA, a restrictive WAF/network policy, and least-privilege admin roles. The dashboard accepts an admin JWT but does not itself implement password/MFA enrollment.

For production, serve the dashboard from a controlled origin and set `ADMIN_ORIGIN` on the API. Keep the API and database private; never expose PostgreSQL directly to the browser.

The API denies admin endpoints unless the authenticated JWT role is `ADMIN`.
