-- Initial production foundation migration. Generated from prisma/schema.prisma.
CREATE TYPE "PaymentStatus" AS ENUM ('PENDING','SUCCESS','FAILED','REVERSED');
CREATE TYPE "PaymentProvider" AS ENUM ('PAYSTACK','FLUTTERWAVE');
CREATE TYPE "LedgerDirection" AS ENUM ('DEBIT','CREDIT');
CREATE TYPE "OtpPurpose" AS ENUM ('LOGIN','SIGNUP','RESET_PIN');
CREATE TABLE "User" ("id" TEXT PRIMARY KEY,"name" TEXT NOT NULL,"email" TEXT NOT NULL UNIQUE,"phone" TEXT UNIQUE,"passwordHash" TEXT,"pinHash" TEXT,"pinAttempts" INTEGER NOT NULL DEFAULT 0,"lockedUntil" TIMESTAMP(3),"role" TEXT NOT NULL DEFAULT 'CUSTOMER',"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"updatedAt" TIMESTAMP(3) NOT NULL);
CREATE TABLE "Wallet" ("id" TEXT PRIMARY KEY,"userId" TEXT NOT NULL UNIQUE,"currency" TEXT NOT NULL DEFAULT 'NGN',"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"updatedAt" TIMESTAMP(3) NOT NULL);
CREATE TABLE "LedgerAccount" ("id" TEXT PRIMARY KEY,"code" TEXT NOT NULL UNIQUE,"name" TEXT NOT NULL,"currency" TEXT NOT NULL DEFAULT 'NGN');
CREATE TABLE "PaymentIntent" ("id" TEXT PRIMARY KEY,"userId" TEXT NOT NULL,"provider" "PaymentProvider" NOT NULL,"reference" TEXT NOT NULL UNIQUE,"amountKobo" BIGINT NOT NULL,"currency" TEXT NOT NULL DEFAULT 'NGN',"status" "PaymentStatus" NOT NULL DEFAULT 'PENDING',"providerTxId" TEXT,"checkoutUrl" TEXT,"fulfilledAt" TIMESTAMP(3),"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"updatedAt" TIMESTAMP(3) NOT NULL);
CREATE TABLE "OtpChallenge" ("id" TEXT PRIMARY KEY,"userId" TEXT,"destination" TEXT NOT NULL,"purpose" "OtpPurpose" NOT NULL,"codeHash" TEXT NOT NULL,"attempts" INTEGER NOT NULL DEFAULT 0,"expiresAt" TIMESTAMP(3) NOT NULL,"consumedAt" TIMESTAMP(3),"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE "WebhookEvent" ("id" TEXT PRIMARY KEY,"provider" TEXT NOT NULL,"eventId" TEXT NOT NULL,"payloadHash" TEXT NOT NULL,"payload" JSONB NOT NULL,"receivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,"processedAt" TIMESTAMP(3),"status" TEXT NOT NULL DEFAULT 'RECEIVED',UNIQUE("provider","eventId"));
CREATE TABLE "AuditLog" ("id" TEXT PRIMARY KEY,"actorUserId" TEXT,"action" TEXT NOT NULL,"targetType" TEXT,"targetId" TEXT,"metadata" JSONB,"ip" TEXT,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE "LedgerEntry" ("id" TEXT PRIMARY KEY,"userId" TEXT,"accountId" TEXT NOT NULL,"paymentIntentId" TEXT,"direction" "LedgerDirection" NOT NULL,"amountKobo" BIGINT NOT NULL,"currency" TEXT NOT NULL DEFAULT 'NGN',"reference" TEXT NOT NULL UNIQUE,"createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX "OtpChallenge_destination_purpose_idx" ON "OtpChallenge"("destination","purpose");
ALTER TABLE "Wallet" ADD CONSTRAINT "Wallet_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "PaymentIntent" ADD CONSTRAINT "PaymentIntent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "OtpChallenge" ADD CONSTRAINT "OtpChallenge_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "LedgerEntry" ADD CONSTRAINT "LedgerEntry_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "LedgerEntry" ADD CONSTRAINT "LedgerEntry_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "LedgerAccount"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "LedgerEntry" ADD CONSTRAINT "LedgerEntry_paymentIntentId_fkey" FOREIGN KEY ("paymentIntentId") REFERENCES "PaymentIntent"("id") ON DELETE SET NULL ON UPDATE CASCADE;

