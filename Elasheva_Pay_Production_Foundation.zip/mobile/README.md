# Elasheva Pay Mobile

The existing HTML prototype can be replaced by a Flutter client using the API in `../src/server.ts`.

Recommended screens:
- Splash
- Sign up
- Login
- OTP verification
- Dashboard
- Fund wallet
- Hosted payment checkout
- Payment result
- Transactions
- Receipt
- Profile
- PIN setup/change

The mobile app should only receive publishable/client-safe configuration. Provider secret keys belong exclusively on the backend.
