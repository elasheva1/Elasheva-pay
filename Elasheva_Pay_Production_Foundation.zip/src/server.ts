import Fastify from "fastify";
import fastifyJwt from "@fastify/jwt";
import bcrypt from "bcryptjs";
import { PrismaClient, PaymentProvider, PaymentStatus, LedgerDirection } from "@prisma/client";
import { z } from "zod";
import crypto from "node:crypto";

const prisma = new PrismaClient();
const app = Fastify({ logger: true });

const env = {
  port: Number(process.env.PORT ?? 3000),
  jwtSecret: process.env.JWT_SECRET ?? "dev-only-change-me",
  paystackSecret: process.env.PAYSTACK_SECRET_KEY ?? "",
  paystackWebhookSecret: process.env.PAYSTACK_WEBHOOK_SECRET ?? "",
  appBaseUrl: process.env.APP_BASE_URL ?? "http://localhost:3000"
};

await app.register(fastifyJwt, { secret: env.jwtSecret });

declare module "@fastify/jwt" {
  interface FastifyJWT {
    user: { id: string; email: string };
  }
}

function nairaToKobo(amount: number) {
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Invalid amount");
  return BigInt(Math.round(amount * 100));
}

async function auth(request: any, reply: any) {
  try {
    await request.jwtVerify();
  } catch {
    return reply.code(401).send({ error: "Unauthorized" });
  }
}

app.get("/health", async () => ({ ok: true, service: "elasheva-pay-api" }));

app.post("/v1/auth/register", async (request, reply) => {
  const input = z.object({
    name: z.string().min(2).max(100),
    email: z.string().email(),
    phone: z.string().min(7).max(20).optional(),
    password: z.string().min(8).max(128)
  }).parse(request.body);

  const passwordHash = await bcrypt.hash(input.password, 12);

  try {
    const user = await prisma.user.create({
      data: {
        name: input.name,
        email: input.email.toLowerCase(),
        phone: input.phone,
        passwordHash,
        wallet: { create: {} }
      },
      select: { id: true, name: true, email: true, phone: true }
    });
    const token = app.jwt.sign({ id: user.id, email: user.email });
    return reply.code(201).send({ user, token });
  } catch {
    return reply.code(409).send({ error: "Email or phone already exists" });
  }
});

app.post("/v1/auth/login", async (request, reply) => {
  const input = z.object({
    email: z.string().email(),
    password: z.string()
  }).parse(request.body);

  const user = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } });
  if (!user || !(await bcrypt.compare(input.password, user.passwordHash))) {
    return reply.code(401).send({ error: "Invalid credentials" });
  }

  const token = app.jwt.sign({ id: user.id, email: user.email });
  return { token };
});

app.get("/v1/wallet", { preHandler: auth }, async (request: any) => {
  const entries = await prisma.ledgerEntry.findMany({
    where: { userId: request.user.id },
    select: { direction: true, amountKobo: true }
  });

  let balance = 0n;
  for (const e of entries) balance += e.direction === LedgerDirection.CREDIT ? e.amountKobo : -e.amountKobo;

  return { currency: "NGN", balanceKobo: balance.toString(), balanceNaira: Number(balance) / 100 };
});

app.post("/v1/payments/initialize", { preHandler: auth }, async (request: any, reply) => {
  const input = z.object({
    amountNaira: z.number().positive().max(10000000),
    provider: z.enum(["paystack"])
  }).parse(request.body);

  const user = await prisma.user.findUnique({ where: { id: request.user.id } });
  if (!user) return reply.code(404).send({ error: "User not found" });

  const amountKobo = nairaToKobo(input.amountNaira);
  const reference = `EP-${crypto.randomUUID()}`;

  if (!env.paystackSecret) return reply.code(503).send({ error: "Payment provider is not configured" });

  const providerResponse = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.paystackSecret}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: user.email,
      amount: amountKobo.toString(),
      currency: "NGN",
      reference,
      callback_url: `${env.appBaseUrl}/v1/payments/callback`
    })
  });

  const data: any = await providerResponse.json();
  if (!providerResponse.ok || !data.status) {
    request.log.error({ data }, "Paystack initialization failed");
    return reply.code(502).send({ error: "Unable to initialize payment" });
  }

  await prisma.paymentIntent.create({
    data: {
      userId: user.id,
      provider: PaymentProvider.PAYSTACK,
      reference,
      amountKobo,
      checkoutUrl: data.data.authorization_url
    }
  });

  return {
    reference,
    checkoutUrl: data.data.authorization_url,
    status: "PENDING"
  };
});

async function verifyPaystack(reference: string) {
  const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${env.paystackSecret}` }
  });
  if (!response.ok) throw new Error("Provider verification failed");
  return await response.json() as any;
}

async function fulfillPayment(reference: string) {
  const intent = await prisma.paymentIntent.findUnique({ where: { reference } });
  if (!intent) throw new Error("Unknown payment reference");
  if (intent.status === PaymentStatus.SUCCESS) return intent;

  const verified = await verifyPaystack(reference);
  const tx = verified.data;

  if (tx.status !== "success") {
    return prisma.paymentIntent.update({
      where: { reference },
      data: { status: PaymentStatus.FAILED }
    });
  }

  const paidKobo = BigInt(Math.round(Number(tx.amount)));
  if (paidKobo < intent.amountKobo || tx.currency !== intent.currency || tx.reference !== intent.reference) {
    throw new Error("Payment verification mismatch");
  }

  return prisma.$transaction(async (db) => {
    const current = await db.paymentIntent.findUnique({ where: { reference } });
    if (!current || current.status === PaymentStatus.SUCCESS) return current;

    const walletAccount = await db.ledgerAccount.upsert({
      where: { code: `WALLET:${current.userId}` },
      update: {},
      create: { code: `WALLET:${current.userId}`, name: `Wallet ${current.userId}` }
    });

    const entry = await db.ledgerEntry.create({
      data: {
        userId: current.userId,
        accountId: walletAccount.id,
        paymentIntentId: current.id,
        direction: LedgerDirection.CREDIT,
        amountKobo: current.amountKobo,
        currency: "NGN",
        reference: `LEDGER-${current.reference}`
      }
    });

    return db.paymentIntent.update({
      where: { id: current.id },
      data: {
        status: PaymentStatus.SUCCESS,
        providerTxId: String(tx.id),
        fulfilledAt: new Date()
      }
    });
  });
}

app.get("/v1/payments/callback", async (request: any, reply) => {
  const reference = z.string().parse(request.query?.reference);
  try {
    await fulfillPayment(reference);
    return reply.redirect(`${env.appBaseUrl}/payment-result?reference=${encodeURIComponent(reference)}`);
  } catch {
    return reply.code(400).send({ error: "Unable to confirm payment" });
  }
});

app.post("/v1/payments/verify/:reference", { preHandler: auth }, async (request: any, reply) => {
  const reference = z.string().parse(request.params.reference);
  const intent = await prisma.paymentIntent.findUnique({ where: { reference } });
  if (!intent || intent.userId !== request.user.id) return reply.code(404).send({ error: "Payment not found" });

  try {
    const result = await fulfillPayment(reference);
    return { reference, status: result?.status };
  } catch (err) {
    request.log.error(err);
    return reply.code(502).send({ error: "Unable to verify payment" });
  }
});

app.post("/v1/webhooks/paystack", async (request: any, reply) => {
  const signature = request.headers["x-paystack-signature"];
  const raw = JSON.stringify(request.body);
  const expected = crypto.createHmac("sha512", env.paystackWebhookSecret).update(raw).digest("hex");

  if (!signature || !crypto.timingSafeEqual(Buffer.from(String(signature)), Buffer.from(expected))) {
    return reply.code(401).send({ error: "Invalid signature" });
  }

  const event = request.body as any;
  const reference = event?.data?.reference;

  await prisma.webhookEvent.create({
    data: {
      provider: "PAYSTACK",
      eventId: event?.id ? String(event.id) : undefined,
      payloadHash: crypto.createHash("sha256").update(raw).digest("hex"),
      payload: event
    }
  }).catch(() => {});

  if (event?.event === "charge.success" && reference) {
    try { await fulfillPayment(reference); }
    catch (err) { request.log.error(err, "Webhook fulfillment failed"); }
  }

  return reply.code(200).send({ received: true });
});

app.get("/v1/transactions", { preHandler: auth }, async (request: any) => {
  const entries = await prisma.ledgerEntry.findMany({
    where: { userId: request.user.id },
    orderBy: { createdAt: "desc" },
    take: 100,
    select: { reference: true, direction: true, amountKobo: true, currency: true, createdAt: true }
  });

  return entries.map(e => ({
    ...e,
    amountKobo: e.amountKobo.toString(),
    amountNaira: Number(e.amountKobo) / 100
  }));
});

app.listen({ port: env.port, host: "0.0.0.0" }).catch(async err => {
  app.log.error(err);
  await prisma.$disconnect();
  process.exit(1);
});
